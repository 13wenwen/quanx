⛔️Star ⛔️Fork ⛔️Share

[Telegram Channel](https://t.me/DivineEngine)

这已经不是一个适用于大多数人的项目，仅献给我的小伙伴们。

*在使用 Github 的项目时阅读 Readme 文件和 Wiki 页面(如果有)是个好习惯。*

**Special thanks to**

- [scomper / Surge](https://github.com/scomper/Surge)
- [lhie1 / Rules](https://github.com/lhie1/Rules)
- [KOP-XIAO / QuantumultX](https://github.com/KOP-XIAO/QuantumultX)
- HotKids
- [Choler / Surge](https://github.com/Choler/Surge)
- [yichahucha / surge](https://github.com/yichahucha/surge)
- [Koolson / Qure](https://github.com/Koolson/Qure)
- [17mon / china_ip_list](https://github.com/17mon/china_ip_list)
- [blackmatrix7 / ios_rule_script](https://github.com/blackmatrix7/ios_rule_script)
- [srk24 / profile](https://github.com/srk24/profile)